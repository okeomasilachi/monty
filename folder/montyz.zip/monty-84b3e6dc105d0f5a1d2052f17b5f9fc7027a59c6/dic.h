#ifndef DIC_H
#define DIC_H

#include "monty.h"
char *num = NULL;

#endif /* DIC_H */
